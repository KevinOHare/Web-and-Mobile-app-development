package com.example.quizforkidz;

import android.support.v7.app.ActionBarActivity;
import android.content.Intent;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;


public class MainActivity extends ActionBarActivity {
	
	MediaPlayer bugSong;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        bugSong = MediaPlayer.create(MainActivity.this, R.raw.dontsquashthatbug);
        bugSong.setLooping(true);
        bugSong.start();
        
        final Button rightanswer = (Button) findViewById(R.id.button1);
        
        rightanswer.setOnClickListener(new View.OnClickListener() {
			
			@Override
			public void onClick(View v) {
				//rightanswer.setEnabled(true);
				Intent changeScreen = new Intent(MainActivity.this,SelectAgeActivity.class);
				//bugSong.stop();
				startActivity(changeScreen);
				
			}
		});
        
    }
}