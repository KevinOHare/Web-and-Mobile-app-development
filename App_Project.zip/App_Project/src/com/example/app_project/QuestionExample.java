package com.example.app_project;





import android.support.v7.app.ActionBarActivity;
import android.graphics.Color;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;


public class QuestionExample extends ActionBarActivity {

	// Button set up
	Button button1;
	Button button2;
	Button button3;
	Button button4;
	
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.example_question);
        
        // create button views and link to xml
        button1 = (Button) findViewById(R.id.button1);
		button2 = (Button) findViewById(R.id.button2);
		button3 = (Button) findViewById(R.id.button3);
		button4 = (Button) findViewById(R.id.button4);
        
        // ****** on click listeners *******
		
		button1.setOnClickListener(new View.OnClickListener() {
			public void onClick(View v) {
				// 
				button1.setBackgroundColor(Color.RED);
				//**Boolean set
				//**selected
				//**timer
			}
		});
		
		button2.setOnClickListener(new View.OnClickListener() {
			public void onClick(View v) {
			
			}
		});
		
		button3.setOnClickListener(new View.OnClickListener() {
			public void onClick(View v) {
				
			}
		});
		
		button4.setOnClickListener(new View.OnClickListener() {
			public void onClick(View v) {
				
			}
		});
		
        
        
        
        
        
        
    }


    
}
